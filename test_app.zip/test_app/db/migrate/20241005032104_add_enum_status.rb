class AddEnumStatus < ActiveRecord::Migration[7.2]
  def change
    add_column :profiles, :status, :string
  end
end
