class CreateProfiles < ActiveRecord::Migration[7.2]
  def change
    create_table :profiles do |t|
      t.integer :category_id
      t.string :description
      t.string :is_completed
      t.timestamps
    end
  end
end
 