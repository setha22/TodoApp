class RemoveOldStatus < ActiveRecord::Migration[7.2]
  def up
    remove_column :profiles, :is_completed
  end
  def down
    add_column :profiles, :is_completed, :string
  end
end
