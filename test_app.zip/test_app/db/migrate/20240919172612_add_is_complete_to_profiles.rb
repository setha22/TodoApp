class AddIsCompleteToProfiles < ActiveRecord::Migration[7.2]
  def change
    add_column :profiles, :is_completed, :boolean 
   
  end
end
