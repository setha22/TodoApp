class CategoryController < ApplicationController
end
