class Category < ApplicationRecord
    has_many :profiles
end
