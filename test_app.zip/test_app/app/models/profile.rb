class Profile < ApplicationRecord
    # to add relationship
    belongs_to :category

end
