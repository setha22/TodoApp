# <% content_for :title, "New Task" %>

# <h1>New Task</h1>

# <%= render "form", profile: @profile %>

# <br>

# <div>
#   <%= link_to "Back to Back to Task", profiles_path %>
# </div>


# to add more categories in Catogries to Task
cmd:
- bin/rails console
- Category.create(name: "Business")
- Category.all

# to add another attribute to an existing table
cmd:
- scarffolds g profiles
- rails generate migration AddColumnNameToTableName column_name:column_type
- rails generate migration AddDescriptionToCategories description:string
- bin/rails db:migrate









# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
